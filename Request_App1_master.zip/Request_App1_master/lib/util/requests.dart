import 'package:flutter/cupertino.dart';

List requests = [
  {
    "img": "assets/facilities1.jpg",
    "title": "Facilities",
    "address": "Requests to Office Stuff",
    

  },
  {
    "img": "assets/techcentral1.jpg",
    "title": "Tech Central",
    "address": "Requests for Computer support",

  },
  {
    "img": "assets/servicenow1.png",
    "title": "Service Now",
    "address": "All Service Now requests",
    "rating": "4.5"
  },
];