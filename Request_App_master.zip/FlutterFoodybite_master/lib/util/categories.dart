import 'package:flutter/material.dart';

List categories = [
  {
    "name": "Chair",
    "color1": Color.fromARGB(100, 0, 0, 0),
    "color2": Color.fromARGB(100, 0, 0, 0),
    "img": "assets/chair2.png"
  },
  {
    "name": "Air Condtioner",
    "color1": Color.fromARGB(100, 0, 0, 0),
    "color2": Color.fromARGB(100, 0, 0, 0),
    "img": "assets/air1.jpg"
  },
  {
    "name": "Laptop",
    "color1": Color.fromARGB(100, 0, 0, 0),
    "color2": Color.fromARGB(100, 0, 0, 0),
    "img": "assets/laptop1.jpg"
  },
  {
    "name": "Report",
    "color1": Color.fromARGB(100, 0, 0, 0),
    "color2": Color.fromARGB(100, 0, 0, 0),
    "img": "assets/report1.png"
  },
];